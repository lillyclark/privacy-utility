This dataset contains GSM measurements from 5 users at the city of Chania throughout a period of  approx. eight months. Their location is pre-determined and static (e.g. their home) in order to avoid GPS inaccuracies and study the RSS nature-behavior at a fixed location during a long time interval. The vast number of measurements and the long time interval revealed several RSS properties. For example, we observed that +/- 2dB fluctuations due to the GSM power control at the downlink channel (BCCH), where the RSS is measured, was reflected to the entire RSS dataset. Moreover, we were able to monitor the changes in the RSS level due to the large scale shadowing-fading.

Although the location of each user is pre-determined and static, the GPS coordinates were recorded by our system in order to validate that each user was indeed into his house. The maximum error of GPS was approximately 20-30 m, while the minimum was 2-5m, therefore, we could validate that the users were in the pre-determined locations.

Another important fact we should consider, is the time interval (dt_i) between the five internal consecutive measurements of RSSI for each record of this dataset. The iPhone's baseband usually needs one second to return the read of RSS. However, in some rare cases there is a significant delay and we should record this delay (dt_i).

Last but not least, this dataset contains only data from the 6056x BTS (Base Transceiver Station) deployment (i.e. all cells begin with 6056x), since we are aware of its location. GSM measurements from other cells are available but they are excluded from this dataset, since mobile network company did not provide cells' actual location. It must be emphasized that in a few cases the location provided by the GPS was wrong due to hardware failures. However, we asked users to validate that they were indeed at the pre-determined locations.

A short description of each measurement's variable follows, for your convenience:


1. timestamp: It contains the exact date and the time moment of the measurement.
2. dt1: rrsi1 was recorded at the time moment timestamp+dt1 . Each measurement contains a burst of 5 consecutive RSS measurements from the iPhone's baseband. System records 5 consecutive RSSIs for many reasons. For example, we can see if the RSS is constant during a few seconds; this will reveal many properties of the wireless channel at the corresponding time moment.
3.dt2: timestamp+dt1+dt2 was the moment when the rssi2 was recorded.
4. and so ...
5. ...
6. ...
7. rssi_ios: RSSI value provided by the iOS private API. rssi_iOS is presented on the iPhone's screen if you press *3001#12345#*. However, iOS software averages rssi1 ... rssi5 during a time interval which is determined internally by the iPhone. Individually, rssi1 ... rssi5 are more accurate since they are provided by the baseband itself through AT commands and they correspond to instantaneous measurements approximately per second (usually dt_i ~=1 sec).
8. rssi1: RSSI, in dBm, read from the iPhone's baseband at timestamp+dt1.
9. rssi2: RSSI, in dBm, read from the iPhone's baseband at timestamp+dt1+dt2.
10. rssi3: RSSI, in dBm, read from the iPhone's baseband at timestamp+dt1+dt3+dt3.
11. rssi4: RSSI, in dBm, read from the iPhone's baseband at timestamp+dt1+dt2+dt3+dt4.
12. rssi5: RSSI, in dBm, read from the iPhone's baseband at timestamp+dt1+dt2+dt3+dt4+dt5.
13. measurementLat: latitude provided by the iPhone's aGPS at the moment timestamp.
14. measurementLon: longitude provided by the iPhone's aGPS at the moment timestamp.
15. finLat: latitude provided by the iPhone's aGPS at the moment timestamp+dt1+dt2+dt3+dt4+dt5
16. finLon: longitude provided by the iPhone's aGPS at the moment timestamp+dt1+dt2+dt3+dt4+dt5. Thus, we can determine if the user was moving during the time interval (timestamp-timestamp+timestamp+dt1+dt2+dt3+dt4+dt5) when the mobile was recording the five consecutive RSSIs.
17.  accur: horizontal accuracy provided by the iPhone's aGPS. Experimentally, we determined that the accuracy provided by the mobile phone was very pessimistic.
18. isMoving: 0 if there is no difference between 13,14 and 15,16. otherwise 1.
19. cellID: the identifier of the cell
19. lac: location area code.
20. mnc: mobile network code, i.e. a specific network provider. For instance, mnc=1 ->Cosmote.
21. arfcn: Absolute radio-frequency channel number.
22. freq_dlink: downlink frequency carrier (calculated by ARFCN).
23. freq_uplin: uplink frequency carrier (calculated by ARFCN).

------------------------------------
2D cartesian coordinates in the systemParameter.mat corresponds to this users' order:

1. 1e33 [469 306]
2. 2222 [955 747]
3. 6882 [907 940]
4. 7cbc [765 272]
5. a841 [926 514]


Base Station (cells 6065x) [690 162]