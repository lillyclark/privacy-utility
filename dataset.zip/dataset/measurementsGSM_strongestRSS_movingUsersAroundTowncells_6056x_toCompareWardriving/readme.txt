These measurements contains ALL the STRONG RSS data which where observed at the city of chania (i.e. all over town) from the 6065x.

The dataset contains ONLY the strongest RSS measurements. Measurements with <-58 dBm signal strength are exluced.

the techniques proposed in the prior art utilize the strongest RSS measurements from a war driving dataset in order to estimate the real location of the Base Stations.